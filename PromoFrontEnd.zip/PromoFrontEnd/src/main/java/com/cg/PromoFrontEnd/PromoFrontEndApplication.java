package com.cg.PromoFrontEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PromoFrontEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromoFrontEndApplication.class, args);
	}
}

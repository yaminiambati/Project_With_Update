package com.cg.PromoFrontEnd.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


public class Inventory {

private int productId;
	/*
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="discountId")
	@OneToOne(targetEntity=Discount.class, mappedBy="inventory")*/
	private Discount discount;
	
	
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public Discount getDiscount() {
		return discount;
	}

	public void setDiscount(Discount discount) {
		this.discount = discount;
	}

	public Inventory() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}

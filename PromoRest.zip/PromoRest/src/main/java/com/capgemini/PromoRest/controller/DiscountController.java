package com.capgemini.PromoRest.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.PromoRest.model.Discount;
import com.capgemini.PromoRest.service.DiscountService;

@RestController
@RequestMapping("/api/v2")
public class DiscountController {
	@Autowired
	private DiscountService discountservice;

	@GetMapping("/discounts")
	public ResponseEntity<List<Discount>> getAllPilots(){
		List<Discount> discounts= discountservice.getAll();
		/*for (Discount discount : discounts) {
			System.out.println(discount);
		}*/
		
		if(discounts.isEmpty()||discounts==null)
			{
			
			return new ResponseEntity
				("Sorry! Discount details not available!",HttpStatus.NOT_FOUND);
	}
		return new ResponseEntity<List<Discount>>(discounts,HttpStatus.OK);
	}
	
		@PostMapping("/discounts")
				public ResponseEntity<Discount> create(@RequestBody Discount discount){
					discountservice.save(discount);
					
					return new ResponseEntity<Discount>(discount,HttpStatus.OK);
				}
		
		 
		/*
		@PostMapping("/discounts")
		public ResponseEntity<WishList> createWishList(@PathVariable("custId") Integer custId, @PathVariable("prodId") Integer prodId) {
			WishList wishList = new WishList();
			Customer customer = customerService.findById(custId);
			Inventory inventory = inventoryService.findById(prodId);
			
			wishList.setCustomers(customer);
			wishList.setInventory(inventory);
			wishList.setActive(true);
			wishListService.save(wishList);
			return new ResponseEntity<WishList>(HttpStatus.OK);
		}*/
		
		@DeleteMapping("/discounts/{discountId}")
		public void deletePilot(@PathVariable("discountId") Integer discountId) {
			
			discountservice.delete(discountId);
			
		}
		
		@PutMapping("discounts/{discountId}")
		public ResponseEntity<Discount> update(@RequestBody Discount discount, @PathVariable("discountId") Integer discountId){
			
			Discount discount1 = discountservice.find(discountId);
			discountservice.save(discount);
			
			return new ResponseEntity<Discount>(discount,HttpStatus.OK);
		}

	
	
}
